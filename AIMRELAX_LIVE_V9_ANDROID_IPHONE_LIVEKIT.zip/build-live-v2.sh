#!/usr/bin/env bash
set -euo pipefail

echo '=== AIMRELAX LIVE V2 ==='

if ! command -v flutter >/dev/null 2>&1; then
  echo 'ERROR: Flutter SDK is required.'
  exit 1
fi

if [[ ! -f pubspec.yaml ]]; then
  echo 'ERROR: Run this script from the Flutter project root.'
  exit 1
fi

if [[ ! -d android ]]; then
  flutter create --platforms=android --org=com.aimrelax --project-name=aimrelax_live .
fi

python3 scripts/configure_android.py
flutter pub get
flutter analyze
flutter clean
flutter pub get
flutter build apk --release

mkdir -p release
cp build/app/outputs/flutter-apk/app-release.apk release/AIMRELAX-LIVE-V2-ANDROID.apk
ls -lh release/AIMRELAX-LIVE-V2-ANDROID.apk
echo '=== ANDROID BUILD SUCCESS ==='
