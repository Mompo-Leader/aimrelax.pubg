import 'package:flutter/material.dart';
import '../live/live_service.dart';

class LiveScreen extends StatefulWidget {
  final Map<String, dynamic> stream;
  const LiveScreen({super.key, required this.stream});
  @override
  State<LiveScreen> createState() => _LiveScreenState();
}

class _LiveScreenState extends State<LiveScreen> {
  final service = LiveService();
  bool loading = true;
  bool mic = true;
  String status = 'Պատրաստվում է screen capture-ը…';

  @override
  void initState() {
    super.initState();
    _start();
  }

  Future<void> _start() async {
    try {
      await service.startPublishing(widget.stream['id'] as String);
      if (mounted) setState(() {
        loading = false;
        status = '🔴 LIVE — բացիր PUBG-ը';
      });
    } catch (e) {
      if (mounted) setState(() {
        loading = false;
        status = 'Սխալ․ $e';
      });
    }
  }

  Future<void> _stop() async {
    await service.stopPublishing(widget.stream['id'] as String);
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        appBar: AppBar(title: const Text('AIMRELAX LIVE')),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(22),
            child: Column(
              children: [
                Expanded(
                  child: Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: Colors.redAccent),
                    ),
                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            loading ? Icons.screen_share : Icons.live_tv,
                            size: 64,
                            color: Colors.redAccent,
                          ),
                          const SizedBox(height: 16),
                          Text(status, textAlign: TextAlign.center,
                              style: const TextStyle(fontSize: 18)),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {
                          setState(() => mic = !mic);
                          service.setMicrophoneEnabled(mic);
                        },
                        icon: Icon(mic ? Icons.mic : Icons.mic_off),
                        label: Text(mic ? 'Միկրոֆոն ON' : 'Միկրոֆոն OFF'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: FilledButton.icon(
                        style: FilledButton.styleFrom(
                          backgroundColor: Colors.red,
                        ),
                        onPressed: _stop,
                        icon: const Icon(Icons.stop),
                        label: const Text('STOP LIVE'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
