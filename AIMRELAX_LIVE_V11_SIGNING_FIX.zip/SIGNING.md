# AIMRELAX Android APK signing

This build explicitly signs the final APK with Android `apksigner` AFTER Flutter finishes building. The workflow then runs `apksigner verify` and fails if signature verification fails.

If no permanent GitHub Secrets are configured, CI creates a temporary test keystore. For production, configure `AIMRELAX_KEYSTORE_B64`, `AIMRELAX_STORE_PASSWORD`, `AIMRELAX_KEY_PASSWORD`, and `AIMRELAX_KEY_ALIAS`.
