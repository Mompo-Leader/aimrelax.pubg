import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter_background/flutter_background.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart' show Helper;
import 'package:livekit_client/livekit_client.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../config/app_config.dart';

class LiveService {
  static final sb = Supabase.instance.client;
  Room? _room;
  String? _streamId;
  bool _androidBackgroundEnabled = false;
  bool _micEnabled = true;
  Timer? _heartbeat;

  Room? get room => _room;
  bool get isConnected => _room?.connectionState == ConnectionState.connected;
  bool get microphoneEnabled => _micEnabled;

  static Future<Map<String, dynamic>> createStream({
    required String title,
    required String streamerName,
  }) async {
    final user = sb.auth.currentUser;
    if (user == null) throw Exception('Մուտք գործեք AIMRELAX account-ով։');

    final row = {
      'streamer_id': user.id,
      'streamer_name': streamerName,
      'title': title,
      'status': 'live',
      'last_seen_at': DateTime.now().toUtc().toIso8601String(),
      'created_at': DateTime.now().toUtc().toIso8601String(),
    };
    final result = await sb.from('live_streams').insert(row).select().single();
    return Map<String, dynamic>.from(result);
  }

  Future<void> startPublishing(String streamId) async {
    final user = sb.auth.currentUser;
    if (user == null) throw Exception('Մուտք գործեք։');
    _streamId = streamId;

    final roomName = 'aimrelax-live-$streamId';
    final tokenData = await _requestToken(
      roomName: roomName,
      role: 'host',
      participantName: _streamerName(),
    );

    final url = tokenData['server_url'] as String?;
    final token = tokenData['participant_token'] as String?;
    if (url == null || url.isEmpty || token == null || token.isEmpty) {
      throw Exception('LiveKit token response is invalid.');
    }

    if (WebRTCPlatform.isAndroid) {
      final granted = await Helper.requestCapturePermission(fullScreenOnly: true);
      if (!granted) throw Exception('Էկրանի նկարահանման թույլտվությունը չտրվեց։');
      await _enableAndroidForegroundService();
    }

    const screenOptions = ScreenShareCaptureOptions(
      useiOSBroadcastExtension: true,
      captureScreenAudio: true,
      maxFrameRate: 30,
    );

    final options = RoomOptions(
      defaultScreenShareCaptureOptions: screenOptions,
      adaptiveStream: true,
      dynacast: true,
    );
    final room = Room(roomOptions: options);
    _room = room;

    try {
      await room.connect(url, token);
      await room.localParticipant.setMicrophoneEnabled(false);
      await room.localParticipant.setScreenShareEnabled(true);
      await _touchHeartbeat(streamId);
      _heartbeat?.cancel();
      _heartbeat = Timer.periodic(const Duration(seconds: 15), (_) => _touchHeartbeat(streamId));

      try {
        await room.localParticipant.setMicrophoneEnabled(true);
        _micEnabled = true;
      } catch (_) {
        _micEnabled = false;
      }
    } catch (_) {
      await _safeDisconnect();
      await _markEnded(streamId);
      rethrow;
    }
  }

  Future<void> _enableAndroidForegroundService() async {
    if (_androidBackgroundEnabled) return;
    final config = FlutterBackgroundAndroidConfig(
      notificationTitle: 'AIMRELAX LIVE',
      notificationText: 'PUBG LIVE-ը ակտիվ է',
      notificationImportance: AndroidNotificationImportance.normal,
      enableWifiLock: true,
    );
    final initialized = await FlutterBackground.initialize(androidConfig: config);
    if (!initialized) throw Exception('Android foreground service-ը չհաջողվեց միացնել։');
    final enabled = await FlutterBackground.enableBackgroundExecution();
    if (!enabled) throw Exception('Android background execution-ը չհաջողվեց միացնել։');
    _androidBackgroundEnabled = true;
  }

  Future<void> setMicrophoneEnabled(bool enabled) async {
    final room = _room;
    if (room == null) return;
    await room.localParticipant.setMicrophoneEnabled(enabled);
    _micEnabled = enabled;
  }

  Future<void> stopPublishing(String streamId) async {
    _heartbeat?.cancel();
    _heartbeat = null;
    try {
      final room = _room;
      if (room != null) {
        await room.localParticipant.setScreenShareEnabled(false);
        await room.localParticipant.setMicrophoneEnabled(false);
        await room.disconnect();
      }
    } finally {
      _room = null;
      if (_androidBackgroundEnabled) {
        try {
          await FlutterBackground.disableBackgroundExecution();
        } catch (_) {}
        _androidBackgroundEnabled = false;
      }
      await _markEnded(streamId);
      _streamId = null;
    }
  }

  Future<void> dispose() async {
    final id = _streamId;
    if (id != null) {
      await stopPublishing(id);
    } else {
      await _safeDisconnect();
    }
  }

  Future<void> _safeDisconnect() async {
    try {
      await _room?.disconnect();
    } catch (_) {}
    _room = null;
  }

  Future<void> _touchHeartbeat(String streamId) async {
    try {
      await sb.from('live_streams').update({
        'last_seen_at': DateTime.now().toUtc().toIso8601String(),
      }).eq('id', streamId).eq('streamer_id', sb.auth.currentUser!.id).eq('status', 'live');
    } catch (_) {}
  }

  Future<void> _markEnded(String streamId) async {
    try {
      await sb.from('live_streams').update({'status': 'ended'}).eq('id', streamId).eq('streamer_id', sb.auth.currentUser!.id);
    } catch (_) {}
  }

  Future<Map<String, dynamic>> _requestToken({
    required String roomName,
    required String role,
    required String participantName,
  }) async {
    final session = sb.auth.currentSession;
    if (session == null) throw Exception('AIMRELAX session-ը բացակայում է։');

    final response = await sb.functions.invoke(
      'live-token',
      headers: {'Authorization': 'Bearer ${session.accessToken}'},
      body: {
        'room_name': roomName,
        'participant_name': participantName,
        'role': role,
      },
    );

    if (response.status != 200) {
      throw Exception('live-token ${response.status}: ${response.data}');
    }
    final data = response.data;
    if (data is Map<String, dynamic>) return data;
    if (data is Map) return Map<String, dynamic>.from(data);
    return jsonDecode(data.toString()) as Map<String, dynamic>;
  }

  String _streamerName() {
    final user = sb.auth.currentUser;
    final metadata = user?.userMetadata ?? const <String, dynamic>{};
    final value = metadata['full_name'] ?? metadata['name'] ?? metadata['user_name'] ?? user?.email?.split('@').first;
    return (value?.toString().trim().isNotEmpty == true) ? value.toString().trim() : 'AIMRELAX Player';
  }
}

class WebRTCPlatform {
  static bool get isAndroid => !kIsWeb && defaultTargetPlatform == TargetPlatform.android;
}
