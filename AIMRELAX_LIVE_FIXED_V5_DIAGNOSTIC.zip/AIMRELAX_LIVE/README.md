# AIMRELAX LIVE — Android/iPhone streamer

This package is the AIMRELAX PUBG native streamer starter project.

## Backend configuration

The app is configured to use exactly this Supabase project:

- Supabase URL: `https://hvhlrbfjloiahbqmnrly.supabase.co`
- Live token function: `https://hvhlrbfjloiahbqmnrly.supabase.co/functions/v1/live-token`
- Google mobile redirect: `com.aimrelax.live://login-callback/`

The Supabase URL and Live Token URL are centralized in `lib/config/app_config.dart`.
There must be no `hvhlrbfjloiahbqmnrly.supabase.co` hostname in this project.

## Build

The GitHub Actions workflow used by the repository can extract this project from the ZIP and run `flutter build apk --release`.

After replacing the old ZIP with this package, use a fresh Actions run and install the newly generated `app-release.apk`.

## Important

The current project is a native streamer prototype. Android screen capture, WebRTC signaling, Supabase authentication, and website viewer integration are included, but production deployment should still add a TURN server and complete platform-specific background/broadcast configuration.


## V4 configuration
The app validates and trims the Supabase project URL at runtime. The configured hostname is hvhlrbfjloiahbqmnrly.supabase.co.
