#!/usr/bin/env bash
set -euo pipefail

echo '=== AIMRELAX LIVE V2 ==='

if ! command -v flutter >/dev/null 2>&1; then
  echo 'ERROR: Flutter SDK is required.'
  exit 1
fi

if [[ ! -f pubspec.yaml ]]; then
  echo 'ERROR: Run this script from the Flutter project root.'
  exit 1
fi

if [[ ! -d android ]]; then
  flutter create --platforms=android --org=com.aimrelax --project-name=aimrelax_live .
fi

bash scripts/prepare_signing.sh
python3 scripts/configure_android.py
flutter pub get
flutter analyze
flutter clean
flutter pub get
flutter build apk --release

mkdir -p release
APK=build/app/outputs/flutter-apk/app-release.apk
if [[ ! -s "$APK" ]]; then echo 'ERROR: APK missing'; exit 1; fi
APKSIGNER=$(find "${ANDROID_SDK_ROOT:-$ANDROID_HOME}/build-tools" -type f -name apksigner | sort -V | tail -n 1)
if [[ -z "$APKSIGNER" ]]; then echo 'ERROR: apksigner not found'; exit 1; fi
"$APKSIGNER" verify --verbose --print-certs "$APK"
cp "$APK" release/AIMRELAX-LIVE-V2-ANDROID-SIGNED.apk
ls -lh release/AIMRELAX-LIVE-V2-ANDROID-SIGNED.apk
echo '=== ANDROID BUILD SUCCESS ==='
