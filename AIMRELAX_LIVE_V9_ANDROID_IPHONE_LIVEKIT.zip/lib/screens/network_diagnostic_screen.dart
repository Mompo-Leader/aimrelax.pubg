import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import '../config/app_config.dart';

class NetworkDiagnosticScreen extends StatefulWidget {
  const NetworkDiagnosticScreen({super.key});

  @override
  State<NetworkDiagnosticScreen> createState() => _NetworkDiagnosticScreenState();
}

class _NetworkDiagnosticScreenState extends State<NetworkDiagnosticScreen> {
  bool running = false;
  String result = 'Սեղմիր «Ստուգել կապը»։';

  Future<void> runCheck() async {
    setState(() {
      running = true;
      result = 'Ստուգվում է...';
    });

    final host = Uri.parse(AppConfig.normalizedSupabaseUrl).host;
    final uri = Uri.parse(AppConfig.normalizedSupabaseUrl);
    final lines = <String>[];

    try {
      final addresses = await InternetAddress.lookup(host).timeout(const Duration(seconds: 10));
      lines.add('DNS: OK');
      lines.add('Host: $host');
      lines.add('IP: ${addresses.map((a) => a.address).join(', ')}');
    } on TimeoutException {
      lines.add('DNS: TIMEOUT');
      lines.add('Host: $host');
    } catch (e) {
      lines.add('DNS: FAILED');
      lines.add('Host: $host');
      lines.add('Error: $e');
    }

    try {
      final client = HttpClient();
      client.connectionTimeout = const Duration(seconds: 10);
      final request = await client.getUrl(uri).timeout(const Duration(seconds: 10));
      final response = await request.close().timeout(const Duration(seconds: 10));
      lines.add('HTTPS: OK');
      lines.add('HTTP status: ${response.statusCode}');
      await response.drain<void>();
      client.close(force: true);
    } on TimeoutException {
      lines.add('HTTPS: TIMEOUT');
    } catch (e) {
      lines.add('HTTPS: FAILED');
      lines.add('Error: $e');
    }

    if (!mounted) return;
    setState(() {
      running = false;
      result = lines.join('\n');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Network Diagnostic')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('AIMRELAX LIVE կապի ստուգում', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            SelectableText('Supabase URL:\n${AppConfig.normalizedSupabaseUrl}'),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: running ? null : runCheck,
              icon: running
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.network_check),
              label: const Text('ՍՏՈՒԳԵԼ ԿԱՊԸ'),
            ),
            const SizedBox(height: 20),
            SelectableText(result, style: const TextStyle(fontFamily: 'monospace', fontSize: 15)),
          ],
        ),
      ),
    );
  }
}
