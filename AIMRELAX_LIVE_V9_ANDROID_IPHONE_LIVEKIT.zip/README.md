# AIMRELAX LIVE V2 — Android + iPhone

This version uses LiveKit for the complete media/signaling layer instead of custom browser WebRTC signaling.

## What is included

- Android MediaProjection screen sharing
- Android foreground service for long-running PUBG LIVE
- iPhone ReplayKit Broadcast Upload Extension setup
- LiveKit host/viewer token Edge Function
- Supabase `live_streams` metadata
- Website LiveKit viewer
- Microphone ON/OFF
- Live cleanup on explicit STOP
- GitHub Actions Android APK build
- GitHub Actions iOS project preparation/build validation

## Important platform limits

Android internal/game audio depends on the device, Android version and the game's audio-capture policy. iOS system-wide screen capture requires ReplayKit Broadcast Extension configuration and code signing.

The project can be built automatically, but an iPhone device build still requires an Apple Developer signing identity/provisioning profile in the repository/CI environment.
