# iOS screen sharing setup

The Flutter WebRTC package supports screen capture on iOS. For capturing PUBG or another app outside AIMRELAX itself, configure the iOS screen-sharing/broadcast integration in Xcode.

Current flutter_webrtc documentation describes Broadcast Extension mode with `deviceId: "broadcast"`.
The current Apple platform also provides system screen-sharing APIs. Use the current Xcode/iOS SDK documentation for the deployment target you choose.

Required app permissions in Runner/Info.plist:
- NSMicrophoneUsageDescription
- NSCameraUsageDescription (if camera features are later added)

For cross-app broadcasting, add the required screen-sharing/Broadcast Upload target and App Group in Xcode according to the flutter_webrtc iOS screen-sharing instructions.
