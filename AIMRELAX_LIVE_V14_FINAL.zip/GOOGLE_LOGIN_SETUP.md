# AIMRELAX LIVE — Native Google Login

This build uses native `google_sign_in` and Supabase `signInWithIdToken()`.
It does **not** use `signInWithOAuth()` and does not require Chrome for the Google login flow.

## Supabase

Project URL:
`https://hvhlrbfjloiahbqmnrly.supabase.co`

Client key:
`sb_publishable_EcZUkLdUCvV3qWDD7jlvhg_OjTYu1jA`

In Supabase Dashboard → Authentication → Providers → Google:
- Google provider must be enabled.
- The Google Web Client ID must match:
  `553916262884-e6t38573765ffi5jjkkccbkaot452v24.apps.googleusercontent.com`

## Google Cloud / Android

The Android OAuth client must have the exact application package name:
`com.aimrelax.aimrelax_live`

Its SHA-1 must match the certificate that signs the APK.

The Web OAuth client ID is used by the Flutter app as `serverClientId`:
`553916262884-e6t38573765ffi5jjkkccbkaot452v24.apps.googleusercontent.com`

Do not put the VAPID public key in Supabase initialization. VAPID is only for web push.

### Why `canceled` can happen

The Android Google Sign-In plugin documents that a configuration error can be surfaced as `canceled`, especially when the signing SHA, Android package name, or `serverClientId` is wrong.

Therefore a successful build alone does not prove Google OAuth configuration is correct; the Android OAuth client must match the signed APK.
