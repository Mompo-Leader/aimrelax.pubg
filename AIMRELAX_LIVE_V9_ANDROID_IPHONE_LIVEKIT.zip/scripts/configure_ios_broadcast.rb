#!/usr/bin/env ruby
require 'fileutils'
require 'xcodeproj'

project_path = Dir['ios/*.xcodeproj'].first
abort('No iOS Xcode project found') unless project_path
project = Xcodeproj::Project.open(project_path)
main_target = project.targets.find { |t| t.name == 'Runner' }
abort('Runner target not found') unless main_target

app_group = 'group.com.aimrelax.live'
main_bundle = main_target.build_configurations.first.build_settings['PRODUCT_BUNDLE_IDENTIFIER'] || 'com.aimrelax.live'
ext_bundle = "#{main_bundle}.broadcast"
ext_name = 'AIMRELAXBroadcaster'
ext_dir = File.join('ios', ext_name)

# Create extension source and plist.
FileUtils.mkdir_p(ext_dir)
File.write(File.join(ext_dir, 'SampleHandler.swift'), <<~SWIFT)
  import ReplayKit
  import LiveKit

  #if os(iOS)
  @available(iOS 13.0, *)
  final class SampleHandler: LKSampleHandler {
      override var enableLogging: Bool { true }
  }
  #endif
SWIFT

File.write(File.join(ext_dir, 'Info.plist'), <<~PLIST)
  <?xml version="1.0" encoding="UTF-8"?>
  <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
  <plist version="1.0">
  <dict>
    <key>CFBundleDisplayName</key><string>AIMRELAX LIVE Broadcast</string>
    <key>CFBundleExecutable</key><string>$(EXECUTABLE_NAME)</string>
    <key>CFBundleIdentifier</key><string>$(PRODUCT_BUNDLE_IDENTIFIER)</string>
    <key>CFBundleInfoDictionaryVersion</key><string>6.0</string>
    <key>CFBundleName</key><string>$(PRODUCT_NAME)</string>
    <key>CFBundlePackageType</key><string>XPC!</string>
    <key>CFBundleShortVersionString</key><string>$(FLUTTER_BUILD_NAME)</string>
    <key>CFBundleVersion</key><string>$(FLUTTER_BUILD_NUMBER)</string>
    <key>RTCAppGroupIdentifier</key><string>#{app_group}</string>
    <key>NSExtension</key>
    <dict>
      <key>NSExtensionPointIdentifier</key><string>com.apple.broadcast-services-upload</string>
      <key>NSExtensionPrincipalClass</key><string>$(PRODUCT_MODULE_NAME).SampleHandler</string>
    </dict>
  </dict>
  </plist>
PLIST

# Entitlements for main app and extension.
runner_entitlements = File.join('ios', 'Runner', 'Runner.entitlements')
FileUtils.mkdir_p(File.dirname(runner_entitlements))
File.write(runner_entitlements, <<~XML)
  <?xml version="1.0" encoding="UTF-8"?>
  <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
  <plist version="1.0"><dict><key>com.apple.security.application-groups</key><array><string>#{app_group}</string></array></dict></plist>
XML

ext_entitlements = File.join(ext_dir, 'AIMRELAXBroadcaster.entitlements')
File.write(ext_entitlements, <<~XML)
  <?xml version="1.0" encoding="UTF-8"?>
  <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
  <plist version="1.0"><dict><key>com.apple.security.application-groups</key><array><string>#{app_group}</string></array></dict></plist>
XML

# Main target settings.
main_target.build_configurations.each do |config|
  config.build_settings['CODE_SIGN_ENTITLEMENTS'] = 'Runner/Runner.entitlements'
  config.build_settings['IPHONEOS_DEPLOYMENT_TARGET'] = '13.0'
end

# Avoid duplicate target if workflow is re-run.
old = project.targets.find { |t| t.name == ext_name }
if old
  project.targets.delete(old)
end

ext_target = project.new_target(:app_extension, ext_name, :ios, '13.0')
ext_target.product_name = ext_name
ext_target.build_configurations.each do |config|
  config.build_settings['PRODUCT_BUNDLE_IDENTIFIER'] = ext_bundle
  config.build_settings['INFOPLIST_FILE'] = "#{ext_name}/Info.plist"
  config.build_settings['CODE_SIGN_ENTITLEMENTS'] = "#{ext_name}/AIMRELAXBroadcaster.entitlements"
  config.build_settings['SWIFT_VERSION'] = '5.0'
  config.build_settings['IPHONEOS_DEPLOYMENT_TARGET'] = '13.0'
  config.build_settings['APPLICATION_EXTENSION_API_ONLY'] = 'YES'
end

# Add source/plist/entitlements to extension group and build phases.
group = project.main_group.find_subpath(ext_name, true)
src = group.new_file(File.join(ext_name, 'SampleHandler.swift'))
ext_target.source_build_phase.add_file_reference(src)
plist_ref = group.new_file(File.join(ext_name, 'Info.plist'))
ent_ref = group.new_file(File.join(ext_name, 'AIMRELAXBroadcaster.entitlements'))

# Embed extension in Runner.
embed = main_target.copy_files_build_phases.find { |p| p.name == 'Embed Foundation Extensions' }
unless embed
  embed = main_target.new_copy_files_build_phase('Embed Foundation Extensions')
  embed.symbol_dst_subfolder_spec = :plugins
end
embed.add_file_reference(ext_target.product_reference)

# Add target dependency so the extension is built with the app.
main_target.add_dependency(ext_target)

# Add LiveKit's native Swift package to the Broadcast Extension.
# This is the native SDK used by LKSampleHandler.
package_ref = project.root_object.package_references.find { |p| p.repositoryURL == 'https://github.com/livekit/client-sdk-swift.git' }
unless package_ref
  package_ref = project.new(Xcodeproj::Project::Object::XCRemoteSwiftPackageReference)
  package_ref.repositoryURL = 'https://github.com/livekit/client-sdk-swift.git'
  req = Xcodeproj::Project::Object::XCVersionRequirement.new
  req.kind = 'upToNextMajorVersion'
  req.minimumVersion = '2.13.0'
  package_ref.requirement = req
  project.root_object.package_references << package_ref
end

product_dep = project.new(Xcodeproj::Project::Object::XCSwiftPackageProductDependency)
product_dep.product_name = 'LiveKit'
product_dep.package = package_ref
ext_target.package_product_dependencies << product_dep

# ReplayKit framework is used by the broadcast target.
ext_target.frameworks_build_phase.add_file_reference(project.frameworks_group.new_file('System/Library/Frameworks/ReplayKit.framework'), true)

project.save
puts "Configured iOS Broadcast Extension: #{ext_name} (#{ext_bundle})"
