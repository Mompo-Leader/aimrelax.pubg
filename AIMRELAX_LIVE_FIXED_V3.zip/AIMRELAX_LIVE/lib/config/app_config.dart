/// AIMRELAX LIVE backend configuration.
///
/// Keep the Supabase project URL in one place so the Android/iOS app cannot
/// accidentally use an older hostname in another Dart file.
class AppConfig {
  static const String supabaseUrl =
      'https://hvhlrbfjloiahbqmnrly.supabase.co';

  static const String supabasePublishableKey =
      'sb_publishable_EcZUkLdUCvV3qWDD7jlvhg_OjTYu1jA';

  static const String liveTokenUrl =
      'https://hvhlrbfjloiahbqmnrly.supabase.co/functions/v1/live-token';

  static const String googleRedirectUrl =
      'com.aimrelax.live://login-callback/';
}
