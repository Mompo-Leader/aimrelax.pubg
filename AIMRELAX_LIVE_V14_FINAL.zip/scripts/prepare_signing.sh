#!/usr/bin/env bash
set -euo pipefail
mkdir -p android
KEYSTORE="android/aimrelax-release.jks"

: "${AIMRELAX_KEYSTORE_B64:?AIMRELAX_KEYSTORE_B64 secret is required. Do not generate a new signing key for release builds.}"
: "${AIMRELAX_STORE_PASSWORD:?AIMRELAX_STORE_PASSWORD secret is required.}"
: "${AIMRELAX_KEY_PASSWORD:?AIMRELAX_KEY_PASSWORD secret is required.}"
: "${AIMRELAX_KEY_ALIAS:?AIMRELAX_KEY_ALIAS secret is required.}"

rm -f "$KEYSTORE" android/signing.env
printf '%s' "$AIMRELAX_KEYSTORE_B64" | base64 --decode > "$KEYSTORE"

if [[ ! -s "$KEYSTORE" ]]; then
  echo 'ERROR: decoded signing keystore is empty.'
  exit 1
fi

if ! keytool -list -keystore "$KEYSTORE" -storepass "$AIMRELAX_STORE_PASSWORD" -alias "$AIMRELAX_KEY_ALIAS" >/dev/null 2>&1; then
  echo 'ERROR: GitHub signing secrets do not match the keystore.'
  echo 'The build is stopped intentionally so the APK does not receive a new signing certificate.'
  exit 1
fi

cat > android/signing.env <<ENV
AIMRELAX_KEYSTORE=$KEYSTORE
AIMRELAX_STORE_PASSWORD=$AIMRELAX_STORE_PASSWORD
AIMRELAX_KEY_PASSWORD=$AIMRELAX_KEY_PASSWORD
AIMRELAX_KEY_ALIAS=$AIMRELAX_KEY_ALIAS
ENV
chmod 600 android/signing.env "$KEYSTORE"

echo 'Signing keystore verified and ready.'
