# AIMRELAX LIVE — iPhone Google Login / Deep Link

The Flutter app uses this callback for Supabase OAuth:

`com.aimrelax.live://login-callback/`

Add that exact URL to Supabase Dashboard → Authentication → URL Configuration → Redirect URLs.

For iOS, add the `com.aimrelax.live` URL scheme to `ios/Runner/Info.plist` under `CFBundleURLTypes` when creating/building the iOS target.

Also configure the Google provider in Supabase. The app uses Supabase's OAuth flow, so the Google client secret is not stored in the Flutter source.
