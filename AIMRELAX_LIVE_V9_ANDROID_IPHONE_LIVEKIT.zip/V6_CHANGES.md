# AIMRELAX LIVE V6

- Supabase is NOT initialized during app startup.
- Login screen opens even if Supabase DNS/network is unavailable.
- Supabase initializes only when Email or Google login is pressed.
- Network diagnostic remains available before login.
- Login screen displays VERSION V6 so the installed APK can be identified.
