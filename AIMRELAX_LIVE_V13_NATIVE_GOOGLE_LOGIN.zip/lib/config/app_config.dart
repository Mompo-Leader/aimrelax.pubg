/// AIMRELAX LIVE backend configuration.
class AppConfig {
  static const String supabaseUrl =
      'https://hvhlrbfjloiahbqmnrly.supabase.co';

  static const String supabasePublishableKey =
      'sb_publishable_EcZUkLdUCvV3qWDD7jlvhg_OjTYu1jA';

  static const String liveTokenUrl =
      'https://hvhlrbfjloiahbqmnrly.supabase.co/functions/v1/live-token';

  static const String googleRedirectUrl =
      'com.aimrelax.live://login-callback/';

  // Google OAuth Web client ID used as the serverClientId for native Google Sign-In.
  static const String googleWebClientId =
      '553916262884-e6t38573765ffi5jjkkccbkaot452v24.apps.googleusercontent.com';

  // Runtime-normalized values: protects against accidental whitespace in
  // configuration strings before they reach Supabase's HTTP client.
  static String get normalizedSupabaseUrl => supabaseUrl.trim();
  static String get normalizedLiveTokenUrl => liveTokenUrl.trim();
  static String get normalizedGoogleRedirectUrl => googleRedirectUrl.trim();

  static void validate() {
    final url = normalizedSupabaseUrl;
    if (url != 'https://hvhlrbfjloiahbqmnrly.supabase.co') {
      throw StateError('Invalid AIMRELAX Supabase URL configuration.');
    }
    if (url.contains(RegExp(r'\s'))) {
      throw StateError('Supabase URL contains whitespace.');
    }
  }
}
