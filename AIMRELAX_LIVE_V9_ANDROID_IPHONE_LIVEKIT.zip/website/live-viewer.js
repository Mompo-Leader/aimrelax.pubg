/* AIMRELAX LIVE viewer powered by LiveKit. Requires window.sb (Supabase client). */
(async () => {
  const SUPABASE = window.sb;
  if (!SUPABASE) {
    console.warn('AIMRELAX LIVE: window.sb was not found.');
    return;
  }

  const { Room, RoomEvent, Track } = await import('https://cdn.jsdelivr.net/npm/livekit-client@2.15.0/+esm');
  let currentRoom = null;
  let currentStream = null;

  async function getToken(stream, role = 'viewer') {
    const { data: sessionData } = await SUPABASE.auth.getSession();
    if (!sessionData?.session) throw new Error('Մուտք գործեք AIMRELAX account-ով։');

    const { data, error } = await SUPABASE.functions.invoke('live-token', {
      body: {
        room_name: `aimrelax-live-${stream.id}`,
        participant_name: 'AIMRELAX Viewer',
        role
      }
    });
    if (error) throw error;
    return data;
  }

  async function listLiveStreams() {
    const { data, error } = await SUPABASE
      .from('live_streams')
      .select('id,streamer_id,streamer_name,title,status,created_at')
      .eq('status', 'live')
      .gt('last_seen_at', new Date(Date.now() - 45000).toISOString())
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data || [];
  }

  function attachTrack(track, publication, videoElement) {
    if (publication.kind === Track.Kind.Video) {
      track.attach(videoElement);
    } else if (publication.kind === Track.Kind.Audio) {
      const el = track.attach();
      el.autoplay = true;
      el.setAttribute('data-aimrelax-live-audio', 'true');
      document.body.appendChild(el);
    }
  }

  async function openLive(stream, videoElement) {
    await closeLive();
    const tokenData = await getToken(stream);
    const room = new Room({ adaptiveStream: true, dynacast: true });
    currentRoom = room;
    currentStream = stream;

    room.on(RoomEvent.TrackSubscribed, (track, publication) => attachTrack(track, publication, videoElement));
    room.on(RoomEvent.TrackUnsubscribed, (track) => track.detach());
    room.on(RoomEvent.Disconnected, () => {
      if (videoElement) videoElement.srcObject = null;
    });

    await room.connect(tokenData.server_url, tokenData.participant_token, {
      autoSubscribe: true
    });

    for (const publication of room.remoteParticipants.values()) {
      for (const pub of publication.trackPublications.values()) {
        if (pub.track) attachTrack(pub.track, pub, videoElement);
      }
    }
    await videoElement.play().catch(() => {});
  }

  async function closeLive() {
    if (currentRoom) {
      currentRoom.disconnect();
      currentRoom = null;
    }
    document.querySelectorAll('[data-aimrelax-live-audio="true"]').forEach(el => el.remove());
    currentStream = null;
  }

  window.AIMRELAXLiveViewer = { listLiveStreams, openLive, closeLive };
})();
