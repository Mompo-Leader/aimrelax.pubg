from pathlib import Path
login = Path('lib/screens/login_screen.dart').read_text()
if 'signInWithOAuth' in login:
    raise SystemExit('ERROR: OAuth browser flow is still present in login_screen.dart')
for needle in ('GoogleSignIn.instance', 'signInWithIdToken', 'serverClientId: AppConfig.googleWebClientId'):
    if needle not in login:
        raise SystemExit(f'ERROR: required native Google auth element missing: {needle}')
config = Path('lib/config/app_config.dart').read_text()
for needle in ('https://hvhlrbfjloiahbqmnrly.supabase.co', 'sb_publishable_EcZUkLdUCvV3qWDD7jlvhg_OjTYu1jA', '553916262884-e6t38573765ffi5jjkkccbkaot452v24.apps.googleusercontent.com'):
    if needle not in config:
        raise SystemExit(f'ERROR: required configuration value missing: {needle}')
print('Authentication configuration verified: native Google + Supabase publishable key.')
