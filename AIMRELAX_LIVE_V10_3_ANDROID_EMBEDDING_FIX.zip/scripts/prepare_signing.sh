#!/usr/bin/env bash
set -euo pipefail
mkdir -p android
KEYSTORE="android/aimrelax-release.jks"
STORE_PASS="${AIMRELAX_STORE_PASSWORD:-AIMRELAX-TEST-STORE-2026}"
KEY_PASS="${AIMRELAX_KEY_PASSWORD:-AIMRELAX-TEST-KEY-2026}"
ALIAS="${AIMRELAX_KEY_ALIAS:-aimrelax}"
if [[ -n "${AIMRELAX_KEYSTORE_B64:-}" ]]; then
  echo "$AIMRELAX_KEYSTORE_B64" | base64 --decode > "$KEYSTORE"
else
  if [[ ! -f "$KEYSTORE" ]]; then
    keytool -genkeypair -v -keystore "$KEYSTORE" -storepass "$STORE_PASS" -keypass "$KEY_PASS" \
      -alias "$ALIAS" -keyalg RSA -keysize 2048 -validity 10000 \
      -dname "CN=AIMRELAX LIVE, OU=AIMRELAX, O=AIMRELAX, L=Yerevan, ST=Yerevan, C=AM"
  fi
fi
cat > android/signing.env <<EOF
AIMRELAX_KEYSTORE=$KEYSTORE
AIMRELAX_STORE_PASSWORD=$STORE_PASS
AIMRELAX_KEY_PASSWORD=$KEY_PASS
AIMRELAX_KEY_ALIAS=$ALIAS
EOF
chmod 600 android/signing.env "$KEYSTORE"
echo "Signing keystore ready: $KEYSTORE"
