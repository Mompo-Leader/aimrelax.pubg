# Google Login setup

The app now has:
- Email/password login
- Google login through Supabase OAuth
- Android deep-link callback: `com.aimrelax.live://login-callback/`
- Supabase initialized with the correct project URL and publishable key

Before building the APK, add this exact redirect URL in Supabase:

`com.aimrelax.live://login-callback/`

Path: Authentication → URL Configuration → Redirect URLs.

Google provider must already be enabled/configured in Supabase.
