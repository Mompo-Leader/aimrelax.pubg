import 'dart:convert';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';

class LiveService {
  static final sb = Supabase.instance.client;
  static final uuid = const Uuid();

  final Map<String, RTCPeerConnection> _viewerPeers = {};
  MediaStream? _screen;
  MediaStream? _mic;
  RealtimeChannel? _signalChannel;
  String? _streamId;
  String? _userId;

  static Future<Map<String, dynamic>> createStream({
    required String title,
    required String streamerName,
  }) async {
    final user = sb.auth.currentUser;
    if (user == null) throw Exception('Մուտք գործեք AIMRELAX account-ով։');

    final id = uuid.v4();
    final row = {
      'id': id,
      'streamer_id': user.id,
      'streamer_name': streamerName,
      'title': title,
      'status': 'live',
      'created_at': DateTime.now().toUtc().toIso8601String(),
    };
    final result = await sb.from('live_streams').insert(row).select().single();
    return Map<String, dynamic>.from(result);
  }

  Future<void> startPublishing(String streamId) async {
    final user = sb.auth.currentUser;
    if (user == null) throw Exception('Մուտք գործեք։');

    _streamId = streamId;
    _userId = user.id;

    final configuration = {
      'iceServers': [
        {'urls': 'stun:stun.l.google.com:19302'},
        {'urls': 'stun:stun.cloudflare.com:3478'},
      ],
      'sdpSemantics': 'unified-plan',
    };

    // Android: system screen capture.
    // iOS: flutter_webrtc uses iOS screen sharing; for cross-app capture
    // the iOS project must include the Broadcast/Screen Sharing integration.
    _screen = await navigator.mediaDevices.getDisplayMedia({
      'video': {
        'frameRate': 30,
        'width': 1280,
        'height': 720,
      },
      'audio': true,
      'deviceId': 'broadcast',
    });

    for (final track in _screen!.getVideoTracks()) {
      for (final pc in _viewerPeers.values) { await pc.addTrack(track, _screen!); }
    }

    // Microphone is optional and can be disabled independently.
    try {
      _mic = await navigator.mediaDevices.getUserMedia({
        'audio': true,
        'video': false,
      });
      for (final track in _mic!.getAudioTracks()) {
        for (final pc in _viewerPeers.values) { await pc.addTrack(track, _mic!); }
      }
    } catch (_) {
      // Screen stream can continue without mic.
    }

    _signalChannel = sb.channel('aimrelax-live-$streamId');
    await _signalChannel!.subscribe();

    // Existing live_signals table is used for viewer offers and ICE.
    _signalChannel!.onPostgresChanges(
      event: PostgresChangeEvent.insert,
      schema: 'public',
      table: 'live_signals',
      filter: PostgresChangeFilter(
        type: PostgresChangeFilterType.eq,
        column: 'stream_id',
        value: streamId,
      ),
      callback: (payload) async {
        final row = payload.newRecord;
        if (row['receiver_id'] != _userId) return;
        await _handleSignal(Map<String, dynamic>.from(row));
      },
    );
  }

  String kindOf(Map<String, dynamic> row) => row['kind'] as String? ?? '';

  Future<RTCPeerConnection> _createViewerPeer(String viewerId) async {
    final pc = await createPeerConnection({
      'iceServers': [
        {'urls': 'stun:stun.l.google.com:19302'},
        {'urls': 'stun:stun.cloudflare.com:3478'},
      ],
      'sdpSemantics': 'unified-plan',
    });

    for (final t in _screen?.getVideoTracks() ?? <MediaStreamTrack>[]) {
      await pc.addTrack(t, _screen!);
    }
    for (final t in _screen?.getAudioTracks() ?? <MediaStreamTrack>[]) {
      await pc.addTrack(t, _screen!);
    }
    for (final t in _mic?.getAudioTracks() ?? <MediaStreamTrack>[]) {
      await pc.addTrack(t, _mic!);
    }

    pc.onIceCandidate = (candidate) async {
      if (candidate.candidate == null) return;
      await _sendSignal(
        receiverId: viewerId,
        kind: 'ice',
        payload: {
          'candidate': candidate.candidate,
          'sdpMid': candidate.sdpMid,
          'sdpMLineIndex': candidate.sdpMLineIndex,
        },
      );
    };

    return pc;
  }

  Future<void> _handleSignal(Map<String, dynamic> row) async {
    final sender = row['sender_id'] as String?;
    if (sender == null) return;

    var pc = _viewerPeers[sender];
    if (pc == null && kindOf(row) == 'offer') {
      pc = await _createViewerPeer(sender);
      _viewerPeers[sender] = pc;
    }
    if (pc == null) return;

    final kind = kindOf(row);
    final payload = Map<String, dynamic>.from(row['payload'] ?? {});

    if (kind == 'offer') {
      await pc.setRemoteDescription(
        RTCSessionDescription(payload['sdp'] as String, 'offer'),
      );
      final answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      await _sendSignal(
        receiverId: sender,
        kind: 'answer',
        payload: {'sdp': answer.sdp},
      );
    } else if (kind == 'ice') {
      await pc.addCandidate(
        RTCIceCandidate(
          payload['candidate'],
          payload['sdpMid'],
          payload['sdpMLineIndex'],
        ),
      );
    }
  }

  Future<void> _sendSignal({
    required String receiverId,
    required String kind,
    required Map<String, dynamic> payload,
  }) async {
    await sb.from('live_signals').insert({
      'stream_id': _streamId,
      'sender_id': _userId,
      'receiver_id': receiverId,
      'kind': kind,
      'payload': payload,
      'created_at': DateTime.now().toUtc().toIso8601String(),
    });
  }

  void setMicrophoneEnabled(bool enabled) {
    for (final t in _mic?.getAudioTracks() ?? <MediaStreamTrack>[]) {
      t.enabled = enabled;
    }
  }

  Future<void> stopPublishing(String streamId) async {
    for (final t in _screen?.getTracks() ?? <MediaStreamTrack>[]) {
      t.stop();
    }
    for (final t in _mic?.getTracks() ?? <MediaStreamTrack>[]) {
      t.stop();
    }
    for (final pc in _viewerPeers.values) { await pc.close(); }
    _viewerPeers.clear();
    if (_signalChannel != null) {
      await sb.removeChannel(_signalChannel!);
    }
    await sb.from('live_streams').update({
      'status': 'ended',
    }).eq('id', streamId).eq('streamer_id', _userId!);
    _screen = null;
    _mic = null;
    _signalChannel = null;
  }
}
