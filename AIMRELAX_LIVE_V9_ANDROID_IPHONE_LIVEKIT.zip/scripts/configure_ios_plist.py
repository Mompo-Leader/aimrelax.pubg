from pathlib import Path
import plistlib
import re

p = Path('ios/Runner/Info.plist')
if not p.exists():
    raise SystemExit('ios/Runner/Info.plist not found')
with p.open('rb') as f:
    data = plistlib.load(f)
data['NSCameraUsageDescription'] = 'AIMRELAX LIVE may use the camera when enabled.'
data['NSMicrophoneUsageDescription'] = 'AIMRELAX LIVE uses the microphone for live commentary.'
data['RTCAppGroupIdentifier'] = 'group.com.aimrelax.live'

proj = Path('ios/Runner.xcodeproj/project.pbxproj')
project_text = proj.read_text() if proj.exists() else ''
m = re.search(r'PRODUCT_BUNDLE_IDENTIFIER = ([^;]+);', project_text)
main_bundle = m.group(1).strip() if m else 'com.aimrelax.aimrelax_live'
data['RTCScreenSharingExtension'] = main_bundle + '.broadcast'
data['UIBackgroundModes'] = list(dict.fromkeys(data.get('UIBackgroundModes', []) + ['audio']))
# Custom URL scheme for Supabase OAuth.
url_types = data.setdefault('CFBundleURLTypes', [])
entry = next((x for x in url_types if 'CFBundleURLSchemes' in x), None)
if entry is None:
    entry = {'CFBundleTypeRole': 'Editor', 'CFBundleURLSchemes': []}
    url_types.append(entry)
if 'com.aimrelax.live' not in entry['CFBundleURLSchemes']:
    entry['CFBundleURLSchemes'].append('com.aimrelax.live')
with p.open('wb') as f:
    plistlib.dump(data, f)
