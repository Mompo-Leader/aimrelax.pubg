from pathlib import Path
import re

manifest = Path('android/app/src/main/AndroidManifest.xml')
text = manifest.read_text()
perms = [
    'android.permission.INTERNET',
    'android.permission.ACCESS_NETWORK_STATE',
    'android.permission.CHANGE_NETWORK_STATE',
    'android.permission.MODIFY_AUDIO_SETTINGS',
    'android.permission.RECORD_AUDIO',
    'android.permission.CAMERA',
    'android.permission.FOREGROUND_SERVICE',
    'android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION',
    'android.permission.FOREGROUND_SERVICE_MICROPHONE',
    'android.permission.POST_NOTIFICATIONS',
]
app = text.find('<application')
if app < 0:
    raise SystemExit('No <application> in AndroidManifest.xml')
for perm in perms:
    if perm not in text:
        line = f'    <uses-permission android:name="{perm}" />\n'
        text = text[:app] + line + text[app:]
        app += len(line)
service_name = 'de.julianassmann.flutter_background.IsolateHolderService'
if service_name not in text:
    service = f'''\n        <service\n            android:name="{service_name}"\n            android:enabled="true"\n            android:exported="false"\n            android:foregroundServiceType="mediaProjection" />\n'''
    text = text.replace('</application>', service + '    </application>', 1)
manifest.write_text(text)

gradle_kts = Path('android/app/build.gradle.kts')
if gradle_kts.exists():
    s = gradle_kts.read_text()
    if 'create("release")' not in s:
        marker = '    buildTypes {\n'
        block = '''    signingConfigs {\n        create("release") {\n            val propsFile = rootProject.file("key.properties")\n            if (propsFile.exists()) {\n                val props = java.util.Properties()\n                propsFile.inputStream().use { props.load(it) }\n                keyAlias = props.getProperty("keyAlias")\n                keyPassword = props.getProperty("keyPassword")\n                storeFile = props.getProperty("storeFile")?.let { file(it) }\n                storePassword = props.getProperty("storePassword")\n            }\n        }\n    }\n\n'''
        if marker in s:
            s = s.replace(marker, block + marker, 1)
    s = re.sub(r'signingConfig\s*=\s*signingConfigs\.getByName\("debug"\)', 'signingConfig = signingConfigs.getByName("release")', s)
    if 'signingConfig = signingConfigs.getByName("release")' not in s:
        s = s.replace('release {\n', 'release {\n            signingConfig = signingConfigs.getByName("release")\n', 1)
    gradle_kts.write_text(s)
