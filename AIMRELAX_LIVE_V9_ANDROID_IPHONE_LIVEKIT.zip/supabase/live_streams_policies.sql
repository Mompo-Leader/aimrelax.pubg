-- AIMRELAX LIVE metadata policies.
-- Run only after reviewing your existing policies. These policies assume
-- authenticated AIMRELAX users are allowed to start/watch LIVE streams.

alter table public.live_streams add column if not exists last_seen_at timestamptz;

alter table public.live_streams enable row level security;

drop policy if exists "live_streams_select_live" on public.live_streams;
create policy "live_streams_select_live"
on public.live_streams for select
to authenticated
using (status = 'live' or streamer_id = auth.uid());

drop policy if exists "live_streams_insert_own" on public.live_streams;
create policy "live_streams_insert_own"
on public.live_streams for insert
to authenticated
with check (streamer_id = auth.uid());

drop policy if exists "live_streams_update_own" on public.live_streams;
create policy "live_streams_update_own"
on public.live_streams for update
to authenticated
using (streamer_id = auth.uid())
with check (streamer_id = auth.uid());

-- The new architecture uses LiveKit for media and signaling.
-- live_signals can remain unused; do not expose it to clients for the new flow.

-- Optional but recommended: prevent one user from opening multiple simultaneous LIVE rows.
create unique index if not exists live_streams_one_live_per_streamer
on public.live_streams (streamer_id)
where status = 'live';
