import 'dart:async';
import 'package:app_links/app_links.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../config/app_config.dart';
import '../config/supabase_bootstrap.dart';
import 'home_screen.dart';
import 'network_diagnostic_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool loading = false;
  bool googleLoading = false;
  String? error;
  StreamSubscription<AuthState>? _authSubscription;
  StreamSubscription<Uri>? _uriSubscription;
  final AppLinks _appLinks = AppLinks();

  Future<void> _ensureSupabase() async {
    await SupabaseBootstrap.ensureInitialized();
    _authSubscription ??= Supabase.instance.client.auth.onAuthStateChange.listen((data) {
      if (!mounted) return;
      if (data.event == AuthChangeEvent.signedIn ||
          data.event == AuthChangeEvent.initialSession) {
        final session = data.session;
        if (session != null) {
          Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => const HomeScreen()),
            (_) => false,
          );
        }
      }
    });
  }

  Future<void> _handleOAuthUri(Uri uri) async {
    if (!uri.toString().startsWith(AppConfig.normalizedGoogleRedirectUrl)) return;
    try {
      await _ensureSupabase();
      await Supabase.instance.client.auth.getSessionFromUrl(uri);
    } on AuthException catch (e) {
      if (mounted) setState(() => error = e.message);
    } catch (e) {
      if (mounted) setState(() => error = 'Google վերադարձը չհաջողվեց։ $e');
    }
  }

  Future<void> _initOAuthDeepLinks() async {
    try {
      final initialUri = await _appLinks.getInitialLink();
      if (initialUri != null) {
        await _handleOAuthUri(initialUri);
      }
      _uriSubscription ??= _appLinks.uriLinkStream.listen(_handleOAuthUri);
    } catch (e) {
      if (mounted) setState(() => error = 'OAuth callback-ի միացումը չհաջողվեց։ $e');
    }
  }

  @override
  void initState() {
    super.initState();
    _initOAuthDeepLinks();
  }

  @override
  void dispose() {
    _authSubscription?.cancel();
    _uriSubscription?.cancel();
    email.dispose();
    password.dispose();
    super.dispose();
  }

  Future<void> login() async {
    setState(() { loading = true; error = null; });
    try {
      await _ensureSupabase();
      await Supabase.instance.client.auth.signInWithPassword(
        email: email.text.trim(),
        password: password.text,
      );
      if (mounted) {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const HomeScreen()),
          (_) => false,
        );
      }
    } on AuthException catch (e) {
      if (mounted) setState(() => error = e.message);
    } catch (e) {
      if (mounted) setState(() => error = 'Մուտքը չհաջողվեց։');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> loginWithGoogle() async {
    setState(() { googleLoading = true; error = null; });
    try {
      await _ensureSupabase();
      await Supabase.instance.client.auth.signInWithOAuth(
        OAuthProvider.google,
        redirectTo: AppConfig.normalizedGoogleRedirectUrl,
        authScreenLaunchMode: LaunchMode.externalApplication,
      );
    } on AuthException catch (e) {
      if (mounted) setState(() => error = e.message);
    } catch (e) {
      if (mounted) setState(() => error = 'Google-ով մուտքը չհաջողվեց։ $e');
    } finally {
      if (mounted) setState(() => googleLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 430),
              child: Column(
                children: [
                  const Icon(Icons.live_tv, size: 72, color: Colors.red),
                  const SizedBox(height: 16),
                  const Text('AIMRELAX LIVE',
                      style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  const Text('ANDROID + iPHONE', style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 28),
                  TextField(
                    controller: email,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(labelText: 'Email'),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: password,
                    obscureText: true,
                    decoration: const InputDecoration(labelText: 'Գաղտնաբառ'),
                  ),
                  if (error != null) ...[
                    const SizedBox(height: 12),
                    Text(error!, textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.redAccent)),
                  ],
                  const SizedBox(height: 22),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: loading || googleLoading ? null : login,
                      icon: loading
                          ? const SizedBox(width: 18, height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.login),
                      label: const Text('ՄՈՒՏՔ EMAIL-ՈՎ'),
                    ),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: TextButton.icon(
                      onPressed: loading || googleLoading
                          ? null
                          : () => Navigator.of(context).push(
                                MaterialPageRoute(builder: (_) => const NetworkDiagnosticScreen()),
                              ),
                      icon: const Icon(Icons.network_check),
                      label: const Text('ՍՏՈՒԳԵԼ ԿԱՊԸ'),
                    ),
                  ),
                  const SizedBox(height: 4),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: loading || googleLoading ? null : loginWithGoogle,
                      icon: googleLoading
                          ? const SizedBox(width: 18, height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.account_circle),
                      label: const Text('ՄՈՒՏՔ GOOGLE-ՈՎ'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
