AIMRELAX LIVE V6 - network/login fix

- Added visible DNS/HTTPS connection check directly on the login screen.
- Added retry-safe connection checking with timeouts.
- Login now shows the real network/DNS error instead of hiding it behind a generic message.
- Supabase URL remains: https://hvhlrbfjloiahbqmnrly.supabase.co
- Android INTERNET and ACCESS_NETWORK_STATE permissions remain enabled.

Important: a DNS error cannot be repaired purely in Flutter if the phone/network cannot resolve the Supabase hostname. The new check is intended to distinguish DNS failure from HTTPS/Auth failure.
