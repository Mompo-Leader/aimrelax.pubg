#!/usr/bin/env bash
set -euo pipefail
mkdir -p android
KEYSTORE="$PWD/android/aimrelax-release.jks"
if [[ -n "${AIMRELAX_KEYSTORE_B64:-}" ]]; then
  printf '%s' "$AIMRELAX_KEYSTORE_B64" | base64 --decode > "$KEYSTORE"
  STORE_PASSWORD="${AIMRELAX_STORE_PASSWORD:?AIMRELAX_STORE_PASSWORD secret is required when using AIMRELAX_KEYSTORE_B64}"
  KEY_PASSWORD="${AIMRELAX_KEY_PASSWORD:-$STORE_PASSWORD}"
  KEY_ALIAS="${AIMRELAX_KEY_ALIAS:-aimrelax}"
else
  STORE_PASSWORD='AIMRELAX-TEST-STORE-2026'
  KEY_PASSWORD='AIMRELAX-TEST-KEY-2026'
  KEY_ALIAS='aimrelax'
  rm -f "$KEYSTORE"
  keytool -genkeypair -v -keystore "$KEYSTORE" -storetype JKS \
    -storepass "$STORE_PASSWORD" -keypass "$KEY_PASSWORD" \
    -alias "$KEY_ALIAS" -keyalg RSA -keysize 2048 -validity 10000 \
    -dname 'CN=AIMRELAX LIVE, OU=AIMRELAX, O=AIMRELAX, L=Yerevan, ST=Yerevan, C=AM'
fi
cat > android/key.properties <<PROP
storePassword=$STORE_PASSWORD
keyPassword=$KEY_PASSWORD
keyAlias=$KEY_ALIAS
storeFile=$KEYSTORE
PROP
chmod 600 android/key.properties "$KEYSTORE"
