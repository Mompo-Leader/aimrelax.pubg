import { AccessToken } from "https://esm.sh/livekit-server-sdk@2.19.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { ...corsHeaders, "Content-Type": "application/json" },
});

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "POST required" }, 405);

  try {
    const authorization = req.headers.get("Authorization");
    if (!authorization?.startsWith("Bearer ")) return json({ error: "Authentication required" }, 401);

    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY");
    const livekitUrl = Deno.env.get("LIVEKIT_URL");
    const livekitApiKey = Deno.env.get("LIVEKIT_API_KEY");
    const livekitApiSecret = Deno.env.get("LIVEKIT_API_SECRET");
    if (!supabaseUrl || !supabaseAnonKey || !livekitUrl || !livekitApiKey || !livekitApiSecret) {
      return json({ error: "Required secrets are missing" }, 500);
    }

    const userResponse = await fetch(`${supabaseUrl}/auth/v1/user`, {
      headers: { Authorization: authorization, apikey: supabaseAnonKey },
    });
    if (!userResponse.ok) return json({ error: "Invalid or expired session" }, 401);
    const user = await userResponse.json();

    const body = await req.json().catch(() => ({}));
    const roomName = String(body?.room_name || "").trim();
    const participantName = String(body?.participant_name || "AIMRELAX User").trim().slice(0, 80);
    const role = body?.role === "host" ? "host" : "viewer";
    if (!roomName) return json({ error: "room_name is required" }, 400);

    // Host identity is stable; viewer identities are unique per session/tab.
    const identity = role === "host"
      ? `user_${user.id}`
      : `viewer_${user.id}_${crypto.randomUUID().slice(0, 8)}`;

    const token = new AccessToken(livekitApiKey, livekitApiSecret, {
      identity,
      name: participantName,
      ttl: "2h",
    });

    token.addGrant({
      roomJoin: true,
      room: roomName,
      canPublish: role === "host",
      canPublishData: role === "host",
      canSubscribe: true,
    });

    return json({
      server_url: livekitUrl,
      participant_token: await token.toJwt(),
      identity,
      room_name: roomName,
    });
  } catch (error) {
    console.error("live-token error:", error);
    return json({ error: error instanceof Error ? error.message : "Token generation failed" }, 500);
  }
});
