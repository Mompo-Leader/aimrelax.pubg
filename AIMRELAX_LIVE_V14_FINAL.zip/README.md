# AIMRELAX LIVE — Final Android build

This build is based on V13 and fixes the authentication initialization and release-signing problems.

## Authentication

- Supabase URL: `https://hvhlrbfjloiahbqmnrly.supabase.co`
- Supabase Publishable Key: `sb_publishable_EcZUkLdUCvV3qWDD7jlvhg_OjTYu1jA`
- Google Web Client ID: `553916262884-e6t38573765ffi5jjkkccbkaot452v24.apps.googleusercontent.com`
- Email/password uses Supabase `signInWithPassword`.
- Google uses native `google_sign_in` + Supabase `signInWithIdToken`.
- Browser/Chrome OAuth (`signInWithOAuth`) is not used.

## Important Google requirement

The Android OAuth client in Google Cloud must use package name `com.aimrelax.aimrelax_live` and the SHA-1 of the **same release keystore used by GitHub Actions**.

The workflow prints the signing certificate SHA-1. Add that SHA-1 to the Android OAuth client if it is not already there. The Google Android plugin documents that an incorrect package name, signing SHA, or serverClientId can surface as `canceled`.

## Release signing

The workflow intentionally refuses to create a new signing key. This keeps the SHA-1 stable and prevents Google Sign-In from breaking between builds.

Required GitHub Actions secrets:
- `AIMRELAX_KEYSTORE_B64`
- `AIMRELAX_STORE_PASSWORD`
- `AIMRELAX_KEY_PASSWORD`
- `AIMRELAX_KEY_ALIAS`

## Build

Use `.github/workflows/build-apk.yml` and run it from GitHub Actions.
