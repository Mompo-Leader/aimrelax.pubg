import 'package:supabase_flutter/supabase_flutter.dart';
import 'app_config.dart';

class SupabaseBootstrap {
  static bool initialized = false;

  static Future<void> ensureInitialized() async {
    if (initialized) return;
    AppConfig.validate();
    await Supabase.initialize(
      url: AppConfig.normalizedSupabaseUrl,
      publishableKey: AppConfig.supabasePublishableKey,
    );
    initialized = true;
  }
}
