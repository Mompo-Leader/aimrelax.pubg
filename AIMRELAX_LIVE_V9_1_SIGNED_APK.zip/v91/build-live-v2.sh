#!/usr/bin/env bash
set -euo pipefail

echo '=== AIMRELAX LIVE V2 ==='
if ! command -v flutter >/dev/null 2>&1; then echo 'ERROR: Flutter SDK is required.'; exit 1; fi
if [[ ! -f pubspec.yaml ]]; then echo 'ERROR: Run this script from the Flutter project root.'; exit 1; fi
if [[ ! -d android ]]; then flutter create --platforms=android --org=com.aimrelax --project-name=aimrelax_live .; fi
bash scripts/prepare_signing.sh
python3 scripts/configure_android.py
flutter pub get
flutter analyze
flutter clean
flutter pub get
flutter build apk --release
APK='build/app/outputs/flutter-apk/app-release.apk'
test -s "$APK"
APKSIGNER=$(find "${ANDROID_SDK_ROOT:-$ANDROID_HOME}/build-tools" -type f -name apksigner | sort -V | tail -n 1)
test -n "$APKSIGNER"
"$APKSIGNER" verify --verbose --print-certs "$APK"
mkdir -p release
cp "$APK" release/AIMRELAX-LIVE-V2-ANDROID-SIGNED.apk
ls -lh release/AIMRELAX-LIVE-V2-ANDROID-SIGNED.apk
echo '=== ANDROID SIGNED BUILD SUCCESS ==='
