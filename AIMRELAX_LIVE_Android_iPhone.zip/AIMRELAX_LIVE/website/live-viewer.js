/*
 AIMRELAX LIVE viewer bridge.

 Include after Supabase + currentUser are initialized:
   <script src="./live-viewer.js"></script>

 Expected HTML:
   #live-list
   #live-player
   #live-title
   #live-streamer
   #live-viewer-count (optional)
*/

(() => {
  const SUPABASE = window.sb;
  if (!SUPABASE) {
    console.warn('AIMRELAX LIVE viewer: Supabase client not found.');
    return;
  }

  const peers = new Map();
  let currentStream = null;
  let signalChannel = null;

  const iceServers = [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun.cloudflare.com:3478' }
  ];

  async function listLiveStreams() {
    const { data, error } = await SUPABASE
      .from('live_streams')
      .select('id,streamer_id,streamer_name,title,status,created_at')
      .eq('status', 'live')
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  }

  async function openLive(stream, videoElement) {
    await closeLive();

    currentStream = stream;
    signalChannel = SUPABASE.channel(`aimrelax-live-${stream.id}`);

    await signalChannel.subscribe();

    signalChannel.on(
      'broadcast',
      { event: 'live_signal' },
      async ({ payload }) => {
        if (payload?.receiver_id !== SUPABASE.auth.getUser) return;
      }
    );

    const userResult = await SUPABASE.auth.getUser();
    const viewerId = userResult.data.user?.id;
    if (!viewerId) throw new Error('Մուտք գործեք՝ Live դիտելու համար։');

    const pc = new RTCPeerConnection({ iceServers });

    pc.ontrack = (event) => {
      if (event.streams?.[0] && videoElement.srcObject !== event.streams[0]) {
        videoElement.srcObject = event.streams[0];
      }
    };

    pc.onicecandidate = async (event) => {
      if (!event.candidate) return;
      await SUPABASE.from('live_signals').insert({
        stream_id: stream.id,
        sender_id: viewerId,
        receiver_id: stream.streamer_id,
        kind: 'ice',
        payload: {
          candidate: event.candidate.candidate,
          sdpMid: event.candidate.sdpMid,
          sdpMLineIndex: event.candidate.sdpMLineIndex
        },
        created_at: new Date().toISOString()
      });
    };

    const signalSubscription = SUPABASE
      .channel(`aimrelax-viewer-${stream.id}-${viewerId}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'live_signals',
        filter: `stream_id=eq.${stream.id}`
      }, async ({ new: row }) => {
        if (row.receiver_id !== viewerId) return;

        const p = row.payload || {};
        if (row.kind === 'answer') {
          await pc.setRemoteDescription(
            new RTCSessionDescription({ type: 'answer', sdp: p.sdp })
          );
        } else if (row.kind === 'ice') {
          await pc.addIceCandidate(new RTCIceCandidate({
            candidate: p.candidate,
            sdpMid: p.sdpMid,
            sdpMLineIndex: p.sdpMLineIndex
          }));
        }
      });

    await signalSubscription.subscribe();

    const offer = await pc.createOffer({ offerToReceiveAudio: true, offerToReceiveVideo: true });
    await pc.setLocalDescription(offer);

    await SUPABASE.from('live_signals').insert({
      stream_id: stream.id,
      sender_id: viewerId,
      receiver_id: stream.streamer_id,
      kind: 'offer',
      payload: { sdp: offer.sdp },
      created_at: new Date().toISOString()
    });

    peers.set(stream.id, { pc, signalSubscription });
  }

  async function closeLive() {
    const item = currentStream ? peers.get(currentStream.id) : null;
    if (item) {
      item.pc.close();
      await SUPABASE.removeChannel(item.signalSubscription);
      peers.delete(currentStream.id);
    }
    if (signalChannel) {
      await SUPABASE.removeChannel(signalChannel);
      signalChannel = null;
    }
    currentStream = null;
  }

  window.AIMRELAXLiveViewer = {
    listLiveStreams,
    openLive,
    closeLive
  };
})();
