import 'package:flutter_test/flutter_test.dart';
import 'package:aimrelax_live/main.dart';

void main() {
  testWidgets('AIMRELAX LIVE app starts', (WidgetTester tester) async {
    await tester.pumpWidget(const AimrelaxLiveApp());
    expect(find.byType(AimrelaxLiveApp), findsOneWidget);
  });
}
