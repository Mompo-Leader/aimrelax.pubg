# AIMRELAX LIVE Android signing

The CI workflow explicitly signs and verifies the release APK with `apksigner` before uploading it.

For immediate testing, if no GitHub Secrets are configured, CI generates a temporary test keystore. This is enough for installation, but each runner can generate a different key, so an already-installed build may need to be uninstalled before installing a later build.

For stable updates, configure these GitHub Actions secrets with one permanent keystore:
- `AIMRELAX_KEYSTORE_B64`
- `AIMRELAX_STORE_PASSWORD`
- `AIMRELAX_KEY_PASSWORD`
- `AIMRELAX_KEY_ALIAS`

Never commit the private keystore or passwords to the repository.
