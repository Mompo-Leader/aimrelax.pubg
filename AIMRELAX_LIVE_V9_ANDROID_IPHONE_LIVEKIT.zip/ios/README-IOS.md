# AIMRELAX LIVE — iPhone

The iOS workflow generates a Flutter iOS project and adds a ReplayKit Broadcast Upload Extension named `AIMRELAXBroadcaster`.

## Full-screen PUBG capture

The Flutter app uses LiveKit's iOS broadcast screen-share path. The extension subclasses `LKSampleHandler` and shares the same App Group as the main app.

The GitHub Actions workflow validates the iOS project with an unsigned simulator build. A physical iPhone build requires Apple Developer signing and an App Group capability for the main bundle and `.broadcast` extension bundle.

On iOS 27+, LiveKit can use ScreenCaptureKit for system-wide screen capture; this project keeps the Broadcast Extension path enabled for compatibility with older iOS versions as well.
