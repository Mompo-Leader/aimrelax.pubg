# AIMRELAX LIVE — Native Google Login

This version uses `google_sign_in` and Supabase `signInWithIdToken()` for native mobile authentication. It does not call `signInWithOAuth()` for the Google button, so the Google web OAuth redirect/Chrome flow is not used.

Web client ID (serverClientId): `553916262884-e6t38573765ffi5jjkkccbkaot452v24.apps.googleusercontent.com`

Android Google Cloud configuration must contain an Android OAuth client matching the final application package and the SHA-1/SHA-256 of the signing key used for the APK.
