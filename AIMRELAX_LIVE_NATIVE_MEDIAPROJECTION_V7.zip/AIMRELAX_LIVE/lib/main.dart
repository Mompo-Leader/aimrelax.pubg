import 'package:flutter/material.dart';
import 'config/app_config.dart';
import 'config/supabase_bootstrap.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  AppConfig.validate();
  runApp(const AimrelaxLiveApp());
}

class AimrelaxLiveApp extends StatelessWidget {
  const AimrelaxLiveApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AIMRELAX LIVE V6',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        colorSchemeSeed: Colors.red,
        useMaterial3: true,
      ),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    // IMPORTANT: Supabase is intentionally NOT initialized here.
    // This lets the login/diagnostic screen open even when DNS/network
    // access to Supabase is unavailable.
    return const LoginScreen();
  }
}
