# AIMRELAX LIVE — Android + iPhone

This project is the native streamer side for the AIMRELAX PUBG website.

## What it does

- Same AIMRELAX Supabase account for login.
- Creates a row in `public.live_streams`.
- Captures the phone screen through WebRTC.
- Uses `public.live_signals` for WebRTC signaling.
- Android uses MediaProjection through flutter_webrtc.
- iPhone uses iOS screen sharing through flutter_webrtc. Cross-app screen sharing requires the iOS Broadcast/Screen Sharing integration in Xcode.

## Important

The Dart source is the architecture and starting implementation. It has not been compiled in this environment because the Flutter SDK is not installed here.

## Build

1. Install Flutter 3.44+.
2. Run:
   flutter pub get
3. Android:
   flutter build apk --release
4. iOS:
   flutter build ios --release

For iOS App Store/TestFlight, open `ios/Runner.xcworkspace` in Xcode, enable the required Screen Sharing/Broadcast capability and App Group, then configure the Broadcast Upload/Screen Sharing target as required by the selected flutter_webrtc integration.

## Existing Supabase tables

The app expects:

- `public.live_streams`
- `public.live_signals`

The RLS policies already created for AIMRELAX should be retained.

## Production recommendation

Add a TURN server before public release. STUN-only WebRTC can fail on some mobile networks/NATs. For many simultaneous viewers, move from one-peer-per-viewer P2P to an SFU/media server.
