import 'package:flutter_test/flutter_test.dart';
import 'package:aimrelax_live/config/supabase_bootstrap.dart';
import 'package:aimrelax_live/main.dart';

void main() {
  testWidgets('AIMRELAX LIVE app starts', (WidgetTester tester) async {
    await SupabaseBootstrap.ensureInitialized();
    await tester.pumpWidget(const AimrelaxLiveApp());
    await tester.pump();
    expect(find.byType(AimrelaxLiveApp), findsOneWidget);
  });
}
