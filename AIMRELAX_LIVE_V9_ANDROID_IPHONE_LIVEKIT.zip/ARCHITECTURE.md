# AIMRELAX LIVE V2

## Media architecture

Android/iPhone streamer -> LiveKit -> AIMRELAX website viewer.

The previous custom `live_signals` WebRTC offer/answer path has been removed from the media path. LiveKit now handles signaling, ICE negotiation, reconnects and media transport.

### Android

MediaProjection -> LiveKit screen-share track -> LiveKit room.
A foreground service keeps the Flutter process alive while PUBG is in the foreground/background.

### iPhone

iOS Broadcast Upload Extension (ReplayKit) -> LiveKit screen-share track -> LiveKit room.
The Flutter app requests screen share with `useiOSBroadcastExtension: true`.

### Audio

- Microphone: separate LiveKit microphone track, toggleable from the app.
- iOS system/game audio: requested through LiveKit screen-share audio capture where supported by the OS/extension.
- Android internal/game audio: device/OS dependent. The app requests screen capture audio, but Android does not guarantee that every game/device exposes internal audio to third-party capture.

## Backend

Supabase Auth authenticates the user. `live-token` mints a LiveKit host/viewer token. `live_streams` stores only metadata and LIVE state.

Room name is deterministic: `aimrelax-live-<live_streams.id>`.

`live_signals` is no longer needed for media signaling.
