import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'live/live_service.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';

const supabaseUrl = 'https://hvhirbfjloiahbqmnrly.supabase.co';
const supabaseAnonKey = 'sb_publishable_EcZUkLdUCvV3qWDD7jlvhg_OjTYu1jA';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: supabaseUrl,
    anonKey: supabaseAnonKey,
  );
  runApp(const AimrelaxLiveApp());
}

class AimrelaxLiveApp extends StatelessWidget {
  const AimrelaxLiveApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AIMRELAX LIVE',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        colorSchemeSeed: Colors.red,
        useMaterial3: true,
      ),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    final session = Supabase.instance.client.auth.currentSession;
    if (session == null) return const LoginScreen();
    return const HomeScreen();
  }
}
