import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../live/live_service.dart';
import 'live_screen.dart';
import 'login_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final title = TextEditingController(text: 'PUBG LIVE');
  bool starting = false;

  Future<void> start() async {
    setState(() => starting = true);
    try {
      final profile = await Supabase.instance.client
          .from('profiles')
          .select('nickname')
          .eq('id', Supabase.instance.client.auth.currentUser!.id)
          .maybeSingle();

      final nickname = (profile?['nickname'] as String?)?.trim();
      final stream = await LiveService.createStream(
        title: title.text.trim().isEmpty ? 'PUBG LIVE' : title.text.trim(),
        streamerName: nickname?.isNotEmpty == true ? nickname! : 'AIMRELAX Player',
      );

      if (!mounted) return;
      await Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => LiveScreen(stream: stream)),
      );
      if (mounted) setState(() {});
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Live-ը չհաջողվեց սկսել։ $e')),
        );
      }
    } finally {
      if (mounted) setState(() => starting = false);
    }
  }

  Future<void> logout() async {
    await Supabase.instance.client.auth.signOut();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (_) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AIMRELAX LIVE'),
        actions: [IconButton(onPressed: logout, icon: const Icon(Icons.logout))],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('PUBG Screen Live',
                  style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text('Հեռախոսի էկրանը փոխանցվում է AIMRELAX կայքի դիտողներին։'),
              const SizedBox(height: 26),
              TextField(
                controller: title,
                maxLength: 100,
                decoration: const InputDecoration(
                  labelText: 'Live-ի վերնագիր',
                  border: OutlineInputBorder(),
                ),
              ),
              const Spacer(),
              FilledButton.icon(
                onPressed: starting ? null : start,
                icon: const Icon(Icons.fiber_manual_record),
                label: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 15),
                  child: Text('START LIVE'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
