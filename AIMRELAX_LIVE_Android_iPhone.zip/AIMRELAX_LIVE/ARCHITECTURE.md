# AIMRELAX Live architecture

Android/iPhone streamer -> WebRTC -> AIMRELAX website viewer.

Supabase:
- live_streams = live session metadata
- live_signals = SDP/ICE signaling
- existing Auth/RLS is reused

Android:
MediaProjection + foreground service requirements for Android 14+.

iPhone:
iOS system screen-sharing integration; cross-app PUBG capture requires the platform's screen sharing/broadcast integration.

Production:
TURN is recommended; P2P one-connection-per-viewer is intended as the first working stage.
