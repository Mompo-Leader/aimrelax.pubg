#!/usr/bin/env bash
set -euo pipefail
mkdir -p android
KEYSTORE="android/aimrelax-release.jks"
DEFAULT_PASS="AIMRELAX-TEST-STORE-2026"
DEFAULT_ALIAS="aimrelax"
STORE_PASS="${AIMRELAX_STORE_PASSWORD:-$DEFAULT_PASS}"
KEY_PASS="${AIMRELAX_KEY_PASSWORD:-$STORE_PASS}"
ALIAS="${AIMRELAX_KEY_ALIAS:-$DEFAULT_ALIAS}"

rm -f android/signing.env

# If a supplied base64 keystore exists, verify it BEFORE Gradle/apksigner uses it.
# A javax.crypto.BadPaddingException normally means the keystore bytes and password do not match.
if [[ -n "${AIMRELAX_KEYSTORE_B64:-}" ]]; then
  if ! printf '%s' "$AIMRELAX_KEYSTORE_B64" | base64 --decode > "$KEYSTORE" 2>/dev/null; then
    echo 'WARNING: AIMRELAX_KEYSTORE_B64 is not valid base64; generating a fresh build keystore.'
    rm -f "$KEYSTORE"
  fi
  if [[ -s "$KEYSTORE" ]] && ! keytool -list -keystore "$KEYSTORE" -storepass "$STORE_PASS" -alias "$ALIAS" >/dev/null 2>&1; then
    echo 'WARNING: Supplied keystore cannot be opened with the configured secrets.'
    echo 'WARNING: Falling back to a fresh AIMRELAX build keystore so the APK can be built.'
    rm -f "$KEYSTORE"
    STORE_PASS="$DEFAULT_PASS"
    KEY_PASS="$DEFAULT_PASS"
    ALIAS="$DEFAULT_ALIAS"
  fi
fi

if [[ ! -f "$KEYSTORE" ]]; then
  keytool -genkeypair -v \
    -keystore "$KEYSTORE" \
    -storepass "$STORE_PASS" \
    -keypass "$KEY_PASS" \
    -alias "$ALIAS" \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -dname "CN=AIMRELAX LIVE, OU=AIMRELAX, O=AIMRELAX, L=Yerevan, ST=Yerevan, C=AM"
fi

# Final validation: fail with a clear message instead of a cryptic crypto exception.
keytool -list -keystore "$KEYSTORE" -storepass "$STORE_PASS" -alias "$ALIAS" >/dev/null

cat > android/signing.env <<ENV
AIMRELAX_KEYSTORE=$KEYSTORE
AIMRELAX_STORE_PASSWORD=$STORE_PASS
AIMRELAX_KEY_PASSWORD=$KEY_PASS
AIMRELAX_KEY_ALIAS=$ALIAS
ENV
chmod 600 android/signing.env "$KEYSTORE"
echo "Signing keystore ready: $KEYSTORE (alias=$ALIAS)"
