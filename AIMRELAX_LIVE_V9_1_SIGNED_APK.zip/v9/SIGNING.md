# AIMRELAX LIVE Android signing

The CI workflow now explicitly signs and verifies the release APK. Android requires every APK to have a developer certificate/signature.

For immediate testing, if no GitHub Secrets are configured, the workflow generates a temporary test keystore in the runner and verifies it with `apksigner`.

For stable updates (so future APKs can update an installed build instead of requiring uninstall), configure these GitHub Actions secrets:

- `AIMRELAX_KEYSTORE_B64` — base64 of your permanent `.jks`
- `AIMRELAX_STORE_PASSWORD`
- `AIMRELAX_KEY_PASSWORD`
- `AIMRELAX_KEY_ALIAS`

Do not commit a private keystore or passwords to the repository.
