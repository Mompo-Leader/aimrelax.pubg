/// AIMRELAX LIVE backend configuration.
class AppConfig {
  static const String supabaseUrl =
      'https://hvhlrbfjloiahbqmnrly.supabase.co';

  static const String supabasePublishableKey =
      'sb_publishable_EcZUkLdUCvV3qWDD7jlvhg_OjTYu1jA';

  static const String liveTokenUrl =
      'https://hvhlrbfjloiahbqmnrly.supabase.co/functions/v1/live-token';

  static const String googleRedirectUrl =
      'com.aimrelax.live://login-callback/';

  // Runtime-normalized values: protects against accidental whitespace in
  // configuration strings before they reach Supabase's HTTP client.
  static String get normalizedSupabaseUrl => supabaseUrl.trim();
  static String get normalizedLiveTokenUrl => liveTokenUrl.trim();
  static String get normalizedGoogleRedirectUrl => googleRedirectUrl.trim();

  static void validate() {
    final url = normalizedSupabaseUrl;
    if (url != 'https://hvhlrbfjloiahbqmnrly.supabase.co') {
      throw StateError('Invalid AIMRELAX Supabase URL configuration.');
    }
    if (url.contains(RegExp(r'\s'))) {
      throw StateError('Supabase URL contains whitespace.');
    }
  }
}
