from pathlib import Path
import re

# Fail early if Flutter generated an obsolete/incomplete Android host.
activity = Path('android/app/src/main/kotlin/com/aimrelax/aimrelax_live/MainActivity.kt')
if not activity.exists():
    raise SystemExit('Modern Flutter MainActivity.kt is missing; Android v1 embedding project detected or Android project is incomplete.')

manifest = Path('android/app/src/main/AndroidManifest.xml')
text = manifest.read_text()
perms = [
    'android.permission.INTERNET',
    'android.permission.ACCESS_NETWORK_STATE',
    'android.permission.CHANGE_NETWORK_STATE',
    'android.permission.MODIFY_AUDIO_SETTINGS',
    'android.permission.RECORD_AUDIO',
    'android.permission.CAMERA',
    'android.permission.FOREGROUND_SERVICE',
    'android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION',
    'android.permission.POST_NOTIFICATIONS',
]
app = text.find('<application')
if app < 0:
    raise SystemExit('No <application> in AndroidManifest.xml')
for perm in perms:
    if perm not in text:
        line = f'    <uses-permission android:name="{perm}" />\n'
        text = text[:app] + line + text[app:]
        app += len(line)
service_name = 'de.julianassmann.flutter_background.IsolateHolderService'
if service_name not in text:
    service = f'''\n        <service\n            android:name="{service_name}"\n            android:enabled="true"\n            android:exported="false"\n            android:foregroundServiceType="mediaProjection" />\n'''
    text = text.replace('</application>', service + '    </application>', 1)
manifest.write_text(text)

# Target modern Android SDK when Flutter template exposes the values.
gradle_kts = Path('android/app/build.gradle.kts')
if gradle_kts.exists():
    s = gradle_kts.read_text()
    s = re.sub(r'minSdk\s*=\s*flutter\.minSdkVersion', 'minSdk = 23', s)
    s = re.sub(r'targetSdk\s*=\s*flutter\.targetSdkVersion', 'targetSdk = 35', s)
    gradle_kts.write_text(s)
